<img width="1810" height="1202" alt="image" src="https://github.com/user-attachments/assets/d088603d-9303-4480-8f39-587656ce014a" />


<img width="1828" height="1562" alt="image" src="https://github.com/user-attachments/assets/a686bcc5-1ff0-4e93-a66f-5d1ab9da1be8" />
