> *Comparaison des tailles de fichiers générés : JSON (127 octets), XML (224 octets), Protobuf (41 octets).*

![WhatsApp Image 2025-11-22 at 11 43 44_4486c132](https://github.com/user-attachments/assets/062cb179-954a-4c19-83bb-c60fc461b6cf)
