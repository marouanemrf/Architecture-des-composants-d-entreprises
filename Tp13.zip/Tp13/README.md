@@  H2 console  @@
<img width="2578" height="1738" alt="image" src="https://github.com/user-attachments/assets/28b9ae2f-c1d2-4ddb-bdb0-418c66512987" />

@@  Liste des comptes @@
<img width="2568" height="288" alt="image" src="https://github.com/user-attachments/assets/15093f4e-f4bd-42b6-8741-55cd587ec497" />
