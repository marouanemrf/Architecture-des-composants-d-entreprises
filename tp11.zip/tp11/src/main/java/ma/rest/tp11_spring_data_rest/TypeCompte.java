package ma.rest.tp11_spring_data_rest;

public enum TypeCompte {
    COURANT, EPARGNE
}
