package ma.ws.jaxrs;

public enum TypeCompte {
    COURANT, EPARGNE
}


