package ma.rest.tp11_spring_data_rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tp11SpringDataRestApplicationTests {

    @Test
    void contextLoads() {
    }

}
