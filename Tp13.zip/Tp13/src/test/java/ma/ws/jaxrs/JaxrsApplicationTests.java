package ma.ws.jaxrs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JaxrsApplicationTests {

	@Test
	void contextLoads() {
	}

}
